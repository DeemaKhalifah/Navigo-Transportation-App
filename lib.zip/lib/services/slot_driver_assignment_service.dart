import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

enum SlotAssignmentOutcome {
  assigned,
  noQueue,
  noMatchingDriver,
  noPendingSlot,
  error,
}

class SlotAssignmentResult {
  const SlotAssignmentResult({
    required this.outcome,
    this.driverId,
    this.slotId,
    this.message,
  });

  final SlotAssignmentOutcome outcome;
  final String? driverId;
  final String? slotId;
  final String? message;
}

class SlotDriverAssignmentService {
  SlotDriverAssignmentService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  static const String _routeCollection = 'route';
  static const String _driversCollection = 'drivers';
  static const String _vehiclesCollection = 'vehicles';

  DocumentReference<Map<String, dynamic>> _routeRef(String routeId) {
    return _db.collection(_routeCollection).doc(routeId.trim());
  }

  DocumentReference<Map<String, dynamic>> _driverRef(String driverId) {
    return _db.collection(_driversCollection).doc(driverId.trim());
  }

  DocumentReference<Map<String, dynamic>> _vehicleRef(String vehicleId) {
    return _db.collection(_vehiclesCollection).doc(vehicleId.trim());
  }

  String _normalizeVehicleType(dynamic value) {
    final text = value
        .toString()
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[\s_-]+'), '');

    if (text.contains('micro')) return 'microbus';
    if (text == 'bus') return 'bus';

    return text;
  }

  List<String> _parseQueue(dynamic raw) {
    if (raw is! List) return [];

    final seen = <String>{};
    final out = <String>[];

    for (final item in raw) {
      final id = item.toString().trim();
      if (id.isEmpty || seen.contains(id)) continue;
      seen.add(id);
      out.add(id);
    }

    return out;
  }

  List<Map<String, dynamic>> _parseSlots(dynamic raw) {
    if (raw is! List) return [];

    return raw
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  bool _slotHasNoDriver(Map<String, dynamic> slot) {
    final driverId = slot['driverId'];
    return driverId == null || driverId.toString().trim().isEmpty;
  }

  DateTime _slotDeparture(Map<String, dynamic> slot) {
    final value = slot['departureAt'];

    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value) ?? DateTime(1900);

    return DateTime(1900);
  }

  String _driverStatus(Map<String, dynamic> driverData) {
    return driverData['status']
        .toString()
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[\s_-]+'), '');
  }

  String _vehicleTypeFromDriverAndVehicle({
    required Map<String, dynamic> driverData,
    required Map<String, dynamic>? vehicleData,
  }) {
    final fromDriver =
        driverData['vehicleType'] ?? driverData['type'] ?? driverData['vehicle'];

    if (fromDriver != null && fromDriver.toString().trim().isNotEmpty) {
      return _normalizeVehicleType(fromDriver);
    }

    final fromVehicle = vehicleData?['vehicleType'] ??
        vehicleData?['type'] ??
        vehicleData?['vehicle'] ??
        vehicleData?['vehicle_type'];

    return _normalizeVehicleType(fromVehicle ?? '');
  }

  Future<SlotAssignmentResult> autoAssignUpcomingUnassignedSlots({
    required String routeId,
  }) async {
    try {
      return await _db.runTransaction<SlotAssignmentResult>((tx) async {
        final cleanRouteId = routeId.trim();
        final routeRef = _routeRef(cleanRouteId);

        // =========================
        // READS FIRST
        // =========================

        final routeSnap = await tx.get(routeRef);

        if (!routeSnap.exists) {
          debugPrint('[AutoAssign] Route not found: route/$cleanRouteId');
          return const SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.error,
            message: 'Route not found',
          );
        }

        final routeData = routeSnap.data() ?? {};
        final queue = _parseQueue(routeData['driverQueueIds']);
        final slots = _parseSlots(routeData['scheduleSlots']);

        debugPrint('================ AUTO ASSIGN ================');
        debugPrint('[AutoAssign] routeId=$cleanRouteId');
        debugPrint('[AutoAssign] queue=$queue');
        debugPrint('[AutoAssign] slotsCount=${slots.length}');

        if (queue.isEmpty) {
          debugPrint('[AutoAssign] Queue is empty');
          return const SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.noQueue,
            message: 'Queue is empty',
          );
        }

        final pendingIndexes = <int>[];

        for (int i = 0; i < slots.length; i++) {
          if (_slotHasNoDriver(slots[i])) {
            pendingIndexes.add(i);
          }
        }

        pendingIndexes.sort(
          (a, b) => _slotDeparture(slots[a]).compareTo(
            _slotDeparture(slots[b]),
          ),
        );

        if (pendingIndexes.isEmpty) {
          debugPrint('[AutoAssign] No pending slots with driverId null');
          return const SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.noPendingSlot,
            message: 'No pending slot',
          );
        }

        final driverSnaps =
            <String, DocumentSnapshot<Map<String, dynamic>>>{};

        final vehicleSnaps =
            <String, DocumentSnapshot<Map<String, dynamic>>>{};

        for (final driverId in queue) {
          final driverSnap = await tx.get(_driverRef(driverId));
          driverSnaps[driverId] = driverSnap;

          final driverData = driverSnap.data();
          final vehicleId = driverData?['vehicleId'];

          if (vehicleId != null && vehicleId.toString().trim().isNotEmpty) {
            final vehicleSnap = await tx.get(
              _vehicleRef(vehicleId.toString()),
            );
            vehicleSnaps[vehicleId.toString().trim()] = vehicleSnap;
          }
        }

        // =========================
        // DECIDE
        // =========================

        String? selectedDriverId;
        String? selectedSlotId;
        int? selectedSlotIndex;

        for (final slotIndex in pendingIndexes) {
          final slot = slots[slotIndex];

          final slotVehicleType = _normalizeVehicleType(slot['vehicleType']);

          debugPrint('[AutoAssign] Checking slot=${slot['slotId']}');
          debugPrint('[AutoAssign] slotVehicleType=$slotVehicleType');

          for (final driverId in queue) {
            final driverSnap = driverSnaps[driverId];

            if (driverSnap == null || !driverSnap.exists) {
              debugPrint('[AutoAssign] Skip $driverId: driver doc not found');
              continue;
            }

            final driverData = driverSnap.data() ?? {};
            final status = _driverStatus(driverData);
            final isOnline = driverData['isOnline'] == true;

            debugPrint('[AutoAssign] Check driver=$driverId');
            debugPrint('[AutoAssign] driverStatus=$status');
            debugPrint('[AutoAssign] driverIsOnline=$isOnline');

            if (status != 'available') {
              debugPrint('[AutoAssign] Skip $driverId: not available');
              continue;
            }

            if (!isOnline) {
              debugPrint('[AutoAssign] Skip $driverId: not online');
              continue;
            }

            final vehicleId = driverData['vehicleId']?.toString().trim() ?? '';
            final vehicleData = vehicleId.isEmpty
                ? null
                : vehicleSnaps[vehicleId]?.data();

            final driverVehicleType = _vehicleTypeFromDriverAndVehicle(
              driverData: driverData,
              vehicleData: vehicleData,
            );

            debugPrint('[AutoAssign] driverVehicleType=$driverVehicleType');
            debugPrint('[AutoAssign] slotVehicleType=$slotVehicleType');

            if (driverVehicleType != slotVehicleType) {
              debugPrint('[AutoAssign] Skip $driverId: vehicle mismatch');
              continue;
            }

            selectedDriverId = driverId;
            selectedSlotId = slot['slotId']?.toString();
            selectedSlotIndex = slotIndex;
            break;
          }

          if (selectedDriverId != null) break;
        }

        if (selectedDriverId == null || selectedSlotIndex == null) {
          debugPrint('[AutoAssign] No matching driver found');
          return const SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.noMatchingDriver,
            message: 'No matching driver found',
          );
        }

        // =========================
        // WRITES AFTER READS
        // =========================

        final updatedSlots = slots
            .map((slot) => Map<String, dynamic>.from(slot))
            .toList();

        updatedSlots[selectedSlotIndex]['driverId'] = selectedDriverId;
        updatedSlots[selectedSlotIndex]['status'] = 'assigned';
        updatedSlots[selectedSlotIndex]['assignedAt'] = Timestamp.now();

        final updatedQueue = List<String>.from(queue);
        updatedQueue.remove(selectedDriverId);
        updatedQueue.add(selectedDriverId);

        tx.update(routeRef, {
          'scheduleSlots': updatedSlots,
          'driverQueueIds': updatedQueue,
        });

        tx.update(_driverRef(selectedDriverId), {
          'status': 'assigned',
          'isOnline': true,
          'updatedAt': FieldValue.serverTimestamp(),
        });

        debugPrint(
          '[AutoAssign] SUCCESS driver=$selectedDriverId slot=$selectedSlotId',
        );
        debugPrint('[AutoAssign] updatedQueue=$updatedQueue');

        return SlotAssignmentResult(
          outcome: SlotAssignmentOutcome.assigned,
          driverId: selectedDriverId,
          slotId: selectedSlotId,
          message: 'Assigned successfully',
        );
      });
    } catch (e) {
      debugPrint('[AutoAssign] ERROR: $e');
      return SlotAssignmentResult(
        outcome: SlotAssignmentOutcome.error,
        message: e.toString(),
      );
    }
  }

  Future<SlotAssignmentResult> tryAssignOldestPendingTripForDriver({
    required String routeId,
    required String driverId,
  }) async {
    try {
      return await _db.runTransaction<SlotAssignmentResult>((tx) async {
        final cleanRouteId = routeId.trim();
        final cleanDriverId = driverId.trim();

        final routeRef = _routeRef(cleanRouteId);
        final driverRef = _driverRef(cleanDriverId);

        // =========================
        // READS FIRST
        // =========================

        final routeSnap = await tx.get(routeRef);
        final driverSnap = await tx.get(driverRef);

        if (!routeSnap.exists || !driverSnap.exists) {
          debugPrint('[AssignForDriver] Route or driver missing');
          return const SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.error,
            message: 'Route or driver not found',
          );
        }

        final routeData = routeSnap.data() ?? {};
        final driverData = driverSnap.data() ?? {};

        final queue = _parseQueue(routeData['driverQueueIds']);
        final slots = _parseSlots(routeData['scheduleSlots']);

        final vehicleId = driverData['vehicleId']?.toString().trim() ?? '';

        DocumentSnapshot<Map<String, dynamic>>? vehicleSnap;

        if (vehicleId.isNotEmpty) {
          vehicleSnap = await tx.get(_vehicleRef(vehicleId));
        }

        // =========================
        // DECIDE
        // =========================

        final status = _driverStatus(driverData);
        final isOnline = driverData['isOnline'] == true;

        debugPrint('============= ASSIGN FOR DRIVER =============');
        debugPrint('[AssignForDriver] routeId=$cleanRouteId');
        debugPrint('[AssignForDriver] driverId=$cleanDriverId');
        debugPrint('[AssignForDriver] status=$status');
        debugPrint('[AssignForDriver] isOnline=$isOnline');
        debugPrint('[AssignForDriver] queue=$queue');

        if (status != 'available') {
          return SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.noMatchingDriver,
            driverId: cleanDriverId,
            message: 'Driver is not available',
          );
        }

        if (!isOnline) {
          return SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.noMatchingDriver,
            driverId: cleanDriverId,
            message: 'Driver is not online',
          );
        }

        final driverVehicleType = _vehicleTypeFromDriverAndVehicle(
          driverData: driverData,
          vehicleData: vehicleSnap?.data(),
        );

        debugPrint('[AssignForDriver] driverVehicleType=$driverVehicleType');

        final pendingIndexes = <int>[];

        for (int i = 0; i < slots.length; i++) {
          if (_slotHasNoDriver(slots[i])) {
            pendingIndexes.add(i);
          }
        }

        pendingIndexes.sort(
          (a, b) => _slotDeparture(slots[a]).compareTo(
            _slotDeparture(slots[b]),
          ),
        );

        int? selectedSlotIndex;
        String? selectedSlotId;

        for (final index in pendingIndexes) {
          final slot = slots[index];
          final slotVehicleType = _normalizeVehicleType(slot['vehicleType']);

          debugPrint('[AssignForDriver] check slot=${slot['slotId']}');
          debugPrint('[AssignForDriver] slotVehicleType=$slotVehicleType');

          if (slotVehicleType == driverVehicleType) {
            selectedSlotIndex = index;
            selectedSlotId = slot['slotId']?.toString();
            break;
          }
        }

        if (selectedSlotIndex == null) {
          return SlotAssignmentResult(
            outcome: SlotAssignmentOutcome.noPendingSlot,
            driverId: cleanDriverId,
            message: 'No matching pending slot',
          );
        }

        // =========================
        // WRITES AFTER READS
        // =========================

        final updatedSlots = slots
            .map((slot) => Map<String, dynamic>.from(slot))
            .toList();

        updatedSlots[selectedSlotIndex]['driverId'] = cleanDriverId;
        updatedSlots[selectedSlotIndex]['status'] = 'assigned';
        updatedSlots[selectedSlotIndex]['assignedAt'] = Timestamp.now();

        final updatedQueue = List<String>.from(queue);

        if (!updatedQueue.contains(cleanDriverId)) {
          updatedQueue.add(cleanDriverId);
        }

        updatedQueue.remove(cleanDriverId);
        updatedQueue.add(cleanDriverId);

        tx.update(routeRef, {
          'scheduleSlots': updatedSlots,
          'driverQueueIds': updatedQueue,
        });

        tx.update(driverRef, {
          'status': 'assigned',
          'isOnline': true,
          'updatedAt': FieldValue.serverTimestamp(),
        });

        debugPrint(
          '[AssignForDriver] SUCCESS driver=$cleanDriverId slot=$selectedSlotId',
        );

        return SlotAssignmentResult(
          outcome: SlotAssignmentOutcome.assigned,
          driverId: cleanDriverId,
          slotId: selectedSlotId,
          message: 'Assigned old pending trip',
        );
      });
    } catch (e) {
      debugPrint('[AssignForDriver] ERROR: $e');
      return SlotAssignmentResult(
        outcome: SlotAssignmentOutcome.error,
        driverId: driverId,
        message: e.toString(),
      );
    }
  }
}