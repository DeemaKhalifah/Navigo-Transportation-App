import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/notification_model.dart';

class NotificationService {
  NotificationService({FirebaseFirestore? firestore, FirebaseAuth? auth})
    : _db = firestore ?? FirebaseFirestore.instance,
      _auth = auth ?? FirebaseAuth.instance;

  final FirebaseFirestore _db;
  final FirebaseAuth _auth;

  Future<void> createTripStartedNotifications({
    required String routeId,
    required String tripId,
    required List<String> passengerIds,
  }) async {
    final driverId = (_auth.currentUser?.uid ?? '').trim();
    final ids = passengerIds
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList();

    if (ids.isEmpty) return;

    final batch = _db.batch();
    for (final passengerId in ids) {
      final ref = _db.collection('notifications').doc();
      final notification = NotificationModel(
        notificationId: ref.id,
        userId: passengerId,
        title: 'Trip Started',
        message: 'Your trip has started 🚍',
        type: 'trip_started',
        driverId: driverId,
        tripId: tripId,
        routeId: routeId,
        isRead: false,
        timestamp: null,
      );

      final map = notification.toMap();
      map['timestamp'] = FieldValue.serverTimestamp();
      batch.set(ref, map);
    }
    await batch.commit();
  }

  Stream<List<NotificationModel>> watchMyNotifications() {
    final uid = _auth.currentUser?.uid;
    if (uid == null || uid.trim().isEmpty) return Stream.value(const []);

    return _db
        .collection('notifications')
        .where('userId', isEqualTo: uid)
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) {
            return NotificationModel.fromMap({
              ...doc.data(),
              'notificationId': doc.id,
            });
          }).toList();
        });
  }

  Future<void> markAsRead(String notificationId) async {
    final id = notificationId.trim();
    if (id.isEmpty) return;
    await _db.collection('notifications').doc(id).update({'isRead': true});
  }
}
