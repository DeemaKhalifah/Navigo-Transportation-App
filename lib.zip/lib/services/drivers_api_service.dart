import 'api_client.dart';

/// Flutter API service for driver-specific backend operations.
class DriversApiService {
  final ApiClient _api = ApiClient();

  /// Get the current driver's profile from the backend.
  Future<Map<String, dynamic>> getDriverProfile() async {
    final response = await _api.get('/drivers/profile');
    return response['data'] as Map<String, dynamic>;
  }

  /// Update driver status (online/offline).
  Future<Map<String, dynamic>> updateStatus(String status) async {
    final response = await _api.put('/drivers/status', body: {
      'status': status,
    });
    return response['data'] as Map<String, dynamic>;
  }

  /// Update driver GPS location.
  Future<void> updateLocation(double latitude, double longitude) async {
    await _api.put('/drivers/location', body: {
      'latitude': latitude,
      'longitude': longitude,
    });
  }

  /// Complete a trip.
  Future<Map<String, dynamic>> completeTrip(String routeId, String slotId) async {
    final response = await _api.post('/drivers/trip/complete', body: {
      'routeId': routeId,
      'slotId': slotId,
    });
    return response['data'] as Map<String, dynamic>;
  }

  void dispose() => _api.dispose();
}
