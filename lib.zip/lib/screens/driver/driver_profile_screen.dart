import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../theme/app_theme.dart';
import '../../controllers/driver_profile_controller.dart';
import '../../models/driver_status.dart';
import 'driver_bottom_nav_bar.dart';
import 'driver_home_screen.dart';
import '../../screens/passenger/support_screen.dart';

/// Driver profile screen — UI only.
/// All business logic is delegated to [DriverProfileController].
class DriverProfileScreen extends StatefulWidget {
  const DriverProfileScreen({super.key});

  @override
  State<DriverProfileScreen> createState() => _DriverProfileScreenState();
}

class _DriverProfileScreenState extends State<DriverProfileScreen> {
  late final DriverProfileController _controller;

  @override
  void initState() {
    super.initState();
    _controller = DriverProfileController();
    _controller.addListener(_onControllerChange);
    _controller.init();
  }

  void _onControllerChange() {
    if (mounted) setState(() {});
  }

  void _showImagePicker() {
    showModalBottomSheet(
      context: context,
      builder: (_) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text("Take Photo"),
                onTap: () {
                  Navigator.pop(context);
                  _controller.pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo),
                title: const Text("Choose from Gallery"),
                onTap: () {
                  Navigator.pop(context);
                  _controller.pickImage(ImageSource.gallery);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _handleSaveProfile() async {
    final error = await _controller.saveProfile();
    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(error)));
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text("Profile updated")));
    }
  }

  Future<void> _handleGoOnline() async {
    final error = await _controller.goOnline();
    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(error)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('You are online and in the driver queue.')),
      );
    }
  }

  Future<void> _handleGoOffline() async {
    final error = await _controller.goOffline();
    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(error)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('You are offline and left the queue.')),
      );
    }
  }

  Future<void> _handleLogout() async {
    await _controller.logout();
    if (mounted) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onControllerChange);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: const DriverBottomNavBar(currentIndex: 3),
      body: SafeArea(
        child: Column(
          children: [
            NavigoDecorations.topBar(
              onBack: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => DriverHomeScreen()),
              ),
              context: context,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Profile", style: NavigoTextStyles.titleLarge),
                  IconButton(
                    onPressed: _controller.toggleEdit,
                    icon: Icon(
                      _controller.isEditing ? Icons.close : Icons.edit,
                      color: NavigoColors.accentGreen,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _controller.isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : SingleChildScrollView(
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        padding: const EdgeInsets.all(20),
                        decoration: NavigoDecorations.kCardDecoration,
                        child: Column(
                          children: [
                            // Profile image
                            Stack(
                              children: <Widget>[
                                CircleAvatar(
                                  radius: 50,
                                  backgroundColor: NavigoColors.surfaceWhite,
                                  child: ClipOval(
                                    child: Image(
                                      image: _controller.profileImageProvider,
                                      fit: BoxFit.contain,
                                      width: 80,
                                      height: 80,
                                    ),
                                  ),
                                ),
                                if (_controller.isEditing)
                                  Positioned(
                                    bottom: 0,
                                    right: 0,
                                    child: GestureDetector(
                                      onTap: _showImagePicker,
                                      child: Container(
                                        padding: const EdgeInsets.all(6),
                                        decoration:
                                            NavigoDecorations.iconCircleDecoration(
                                              NavigoColors.accentGreen,
                                            ),
                                        child: const Icon(
                                          Icons.camera_alt,
                                          size: 16,
                                          color: NavigoColors.textLight,
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                            const SizedBox(height: 20),

                            // Name field
                            _field(
                              "Full Name",
                              _controller.nameController,
                              _controller.isEditing,
                              Icons.person,
                            ),
                            const SizedBox(height: 16),

                            // Phone field
                            _field(
                              "Phone",
                              _controller.phoneController,
                              _controller.isEditing,
                              Icons.phone,
                            ),
                            const SizedBox(height: 20),

                            // Save button
                            if (_controller.isEditing)
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: _controller.isSaving
                                      ? null
                                      : _handleSaveProfile,
                                  style:
                                      NavigoDecorations.kPrimaryButtonLargeStyle,
                                  child: _controller.isSaving
                                      ? const SizedBox(
                                          width: 22,
                                          height: 22,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: NavigoColors.textLight,
                                          ),
                                        )
                                      : const Text("Save"),
                                ),
                              ),
                            const SizedBox(height: 16),

                            // Status display
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'Driver status: ${_controller.statusLabel}',
                                style: NavigoTextStyles.bodyMedium.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            if (_controller.onLiveTrip)
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  'Finish your current trip before changing availability.',
                                  style: NavigoTextStyles.bodySmall.copyWith(
                                    color: NavigoColors.textMuted,
                                  ),
                                ),
                              )
                            else if (_controller.assignedTrip)
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  'You have an assigned trip. Start it from Trips or wait until the route manager updates the schedule.',
                                  style: NavigoTextStyles.bodySmall.copyWith(
                                    color: NavigoColors.textMuted,
                                  ),
                                ),
                              ),
                            const SizedBox(height: 16),

                            // Online/Offline buttons
                            Row(
                              children: [
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: (_controller.statusBusy ||
                                            _controller
                                                .blocksAvailabilityToggle ||
                                            _controller.driverStatus ==
                                                DriverStatus.available)
                                        ? null
                                        : _handleGoOnline,
                                    style: NavigoDecorations
                                        .kPrimaryButtonLargeStyle
                                        .copyWith(
                                          backgroundColor:
                                              const WidgetStatePropertyAll(
                                                NavigoColors.accentGreen,
                                              ),
                                        ),
                                    child: const Text('Go online'),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: (_controller.statusBusy ||
                                            _controller
                                                .blocksAvailabilityToggle ||
                                            _controller.driverStatus ==
                                                DriverStatus.offline)
                                        ? null
                                        : _handleGoOffline,
                                    style: NavigoDecorations
                                        .kPrimaryButtonLargeStyle
                                        .copyWith(
                                          backgroundColor:
                                              const WidgetStatePropertyAll(
                                                NavigoColors.accentRed,
                                              ),
                                        ),
                                    child: const Text('Go offline'),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),

                            // Settings section
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                "Settings",
                                style: NavigoTextStyles.titleSmall.copyWith(
                                  color: NavigoColors.textGray,
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            _settingsItem(
                              icon: Icons.help_outline,
                              title: "Help & Support",
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const HelpSupportScreen(),
                                  ),
                                );
                              },
                            ),
                            _settingsItem(
                              icon: Icons.logout,
                              title: "Log out",
                              color: NavigoColors.accentRed,
                              onTap: _handleLogout,
                            ),
                          ],
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(
    String label,
    TextEditingController controller,
    bool enabled,
    IconData icon,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: NavigoTextStyles.label),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          enabled: enabled,
          style: NavigoTextStyles.bodyMedium.copyWith(
            color: NavigoColors.textDark,
            fontWeight: FontWeight.w500,
          ),
          decoration: NavigoDecorations.kInputDecoration.copyWith(
            prefixIcon: Icon(icon, color: NavigoColors.accentGreen),
          ),
        ),
      ],
    );
  }

  Widget _settingsItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color color = NavigoColors.textDark,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: NavigoTextStyles.bodyMedium.copyWith(
          fontWeight: FontWeight.w500,
          color: color,
        ),
      ),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
    );
  }
}
