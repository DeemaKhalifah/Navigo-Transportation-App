import 'package:cloud_firestore/cloud_firestore.dart';

class NotificationModel {
  final String notificationId;
  final String userId;
  final String title;
  final String message;
  final String type;
  final String? driverId;
  final String? tripId;
  final String? routeId;
  final bool isRead;
  final Timestamp? timestamp;

  NotificationModel({
    required this.notificationId,
    required this.userId,
    required this.title,
    required this.message,
    required this.type,
    this.driverId,
    this.tripId,
    this.routeId,
    required this.isRead,
    this.timestamp,
  });

  factory NotificationModel.fromMap(Map<String, dynamic> map) {
    return NotificationModel(
      notificationId: (map['notificationId'] ?? '').toString(),
      userId: (map['userId'] ?? '').toString(),
      title: (map['title'] ?? '').toString(),
      message: (map['message'] ?? map['body'] ?? '').toString(),
      type: (map['type'] ?? '').toString(),
      driverId: map['driverId']?.toString(),
      tripId: map['tripId']?.toString(),
      routeId: map['routeId']?.toString(),
      isRead: map['isRead'] == true,
      timestamp: map['timestamp'] is Timestamp ? map['timestamp'] as Timestamp : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'notificationId': notificationId,
      'userId': userId,
      'title': title,
      'message': message,
      'body': message,
      'type': type,
      'driverId': driverId,
      'tripId': tripId,
      'routeId': routeId,
      'isRead': isRead,
      'timestamp': timestamp,
    };
  }
}