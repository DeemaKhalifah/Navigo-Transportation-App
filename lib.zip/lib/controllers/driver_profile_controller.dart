import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../models/driver_status.dart';
import '../services/drivers_api_service.dart';
import '../services/user_api_service.dart';

/// Manages driver profile state and operations.
/// Data loading and status changes delegate to backend API.
/// Only real-time status stream remains as a thin Firestore proxy.
class DriverProfileController extends ChangeNotifier {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  final DriversApiService _driversApi = DriversApiService();
  final UserApiService _userApi = UserApiService();

  File? image;
  String? imageUrl;
  bool isEditing = false;
  bool isLoading = true;
  bool isSaving = false;
  bool statusBusy = false;

  String driverStatus = DriverStatus.offline;
  String? assignedRouteId;

  User? get currentUser => FirebaseAuth.instance.currentUser;

  /// Real-time Firestore stream subscription for driver status changes.
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _driverDocSub;

  void init() {
    if (currentUser != null) {
      // Keep thin real-time stream for status updates from other clients
      _driverDocSub = FirebaseFirestore.instance
          .collection('drivers')
          .doc(currentUser!.uid)
          .snapshots()
          .listen((snap) {
            if (!snap.exists) return;
            final st = snap.data()?['status'] as String?;
            final rid = snap.data()?['routeId'] as String?;
            if (st != null) {
              driverStatus = st;
              if (rid != null) assignedRouteId = rid;
              notifyListeners();
            }
          });
      loadProfile();
    } else {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadProfile() async {
    try {
      final profile = await _driversApi.getDriverProfile();
      nameController.text =
          "${profile['firstName'] ?? ''} ${profile['lastName'] ?? ''}".trim();
      phoneController.text = profile['phone'] ?? '';
      imageUrl = profile['image'];
      driverStatus = profile['status'] ?? DriverStatus.offline;
      assignedRouteId = profile['routeId'];
    } catch (e) {
      debugPrint("Error loading driver profile: $e");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  void toggleEdit() {
    isEditing = !isEditing;
    notifyListeners();
  }

  Future<void> pickImage(ImageSource source) async {
    final picked = await _picker.pickImage(source: source, imageQuality: 75);
    if (picked != null) {
      image = File(picked.path);
      notifyListeners();
    }
  }

  Future<String?> _uploadProfileImage() async {
    if (image == null || currentUser == null) return imageUrl;
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_images')
          .child('${currentUser!.uid}.jpg');
      await storageRef.putFile(image!);
      return await storageRef.getDownloadURL();
    } catch (e) {
      debugPrint("Image upload error: $e");
      rethrow;
    }
  }

  /// Save profile to backend. Returns error message or null on success.
  Future<String?> saveProfile() async {
    if (currentUser == null) return 'No user';

    isSaving = true;
    notifyListeners();

    try {
      final uploadedImageUrl = await _uploadProfileImage();
      final names = nameController.text.trim().split(" ");
      final firstName = names.isNotEmpty ? names.first : "";
      final lastName = names.length > 1 ? names.sublist(1).join(" ") : "";

      final success = await _userApi.updateProfile(
        firstName: firstName,
        lastName: lastName,
        phone: phoneController.text.trim(),
      );

      if (!success) return 'Failed to update profile';

      imageUrl = uploadedImageUrl;
      isEditing = false;
      isSaving = false;
      notifyListeners();
      return null;
    } catch (e) {
      isSaving = false;
      notifyListeners();
      return "Failed to update profile: $e";
    }
  }

  bool get onLiveTrip => driverStatus == DriverStatus.onTrip;
  bool get assignedTrip => driverStatus == DriverStatus.assigned;
  bool get blocksAvailabilityToggle => onLiveTrip || assignedTrip;

  String get statusLabel {
    switch (driverStatus) {
      case DriverStatus.available:
        return 'Available';
      case DriverStatus.assigned:
        return 'Assigned (start trip when ready)';
      case DriverStatus.onTrip:
        return 'On trip';
      default:
        return 'Offline';
    }
  }

  /// Go online via backend API. Returns error message or null.
  Future<String?> goOnline() async {
    if (currentUser == null || blocksAvailabilityToggle) return null;
    final routeId = assignedRouteId?.trim();
    if (routeId == null || routeId.isEmpty) {
      return 'No route assigned. Update your driver profile in Firestore.';
    }

    statusBusy = true;
    notifyListeners();

    try {
      await _driversApi.updateStatus('online');
      statusBusy = false;
      notifyListeners();
      return null;
    } catch (e) {
      statusBusy = false;
      notifyListeners();
      return 'Could not go online: $e';
    }
  }

  /// Go offline via backend API. Returns error message or null.
  Future<String?> goOffline() async {
    if (currentUser == null || blocksAvailabilityToggle) return null;

    statusBusy = true;
    notifyListeners();

    try {
      await _driversApi.updateStatus('offline');
      statusBusy = false;
      notifyListeners();
      return null;
    } catch (e) {
      statusBusy = false;
      notifyListeners();
      return 'Could not go offline: $e';
    }
  }

  /// Logout — offline via backend API, then sign out.
  Future<void> logout() async {
    try {
      await _driversApi.updateStatus('offline');
    } catch (e) {
      debugPrint('Logout driver cleanup: $e');
    }
    await FirebaseAuth.instance.signOut();
  }

  ImageProvider get profileImageProvider {
    if (image != null) return FileImage(image!);
    if (imageUrl != null && imageUrl!.isNotEmpty) return NetworkImage(imageUrl!);
    return const AssetImage("assets/images/logo.png");
  }

  @override
  void dispose() {
    _driverDocSub?.cancel();
    nameController.dispose();
    phoneController.dispose();
    _driversApi.dispose();
    super.dispose();
  }
}
