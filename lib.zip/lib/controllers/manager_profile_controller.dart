import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../services/user_api_service.dart';

/// Manages route manager profile state and operations.
/// Profile data operations delegate to [UserApiService] → backend API.
/// Password change stays client-side (Firebase Auth SDK requirement).
class ManagerProfileController extends ChangeNotifier {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  final UserApiService _userApi = UserApiService();

  File? image;
  bool isEditing = false;
  bool isLoading = true;
  bool isSaving = false;

  User? get currentUser => FirebaseAuth.instance.currentUser;

  Future<void> init() async {
    if (currentUser == null) {
      isLoading = false;
      notifyListeners();
      return;
    }
    await loadProfile();
  }

  Future<void> loadProfile() async {
    try {
      final data = await _userApi.getProfile();
      if (data != null) {
        nameController.text =
            "${data['firstName'] ?? ''} ${data['lastName'] ?? ''}".trim();
        emailController.text =
            (data['email'] ?? currentUser?.email ?? '').toString();
      }
    } catch (e) {
      debugPrint("Error loading manager data: $e");
    }
    isLoading = false;
    notifyListeners();
  }

  void toggleEdit() {
    isEditing = !isEditing;
    notifyListeners();
  }

  Future<void> pickImage(ImageSource source) async {
    final picked = await _picker.pickImage(source: source);
    if (picked != null) {
      image = File(picked.path);
      notifyListeners();
    }
  }

  /// Save profile to backend. Returns error message or null on success.
  Future<String?> saveProfile() async {
    if (currentUser == null) return 'No user';

    isSaving = true;
    notifyListeners();

    try {
      final fullName = nameController.text.trim();
      final names =
          fullName.isEmpty ? <String>[] : fullName.split(RegExp(r'\s+'));
      final firstName = names.isNotEmpty ? names.first : "";
      final lastName = names.length > 1 ? names.sublist(1).join(" ") : "";

      final success = await _userApi.updateProfile(
        firstName: firstName,
        lastName: lastName,
        phone: '', // manager may not have phone
      );

      isEditing = false;
      isSaving = false;
      notifyListeners();
      return success ? null : 'Failed to update profile';
    } catch (e) {
      isSaving = false;
      notifyListeners();
      return "Failed to update profile: $e";
    }
  }

  /// Change password. Returns error message or null on success.
  /// This is a client-side Firebase Auth operation.
  Future<String?> changePassword(
    String currentPassword,
    String newPassword,
    String confirmPassword,
  ) async {
    final user = currentUser;
    if (user == null || user.email == null) return 'No logged in user found.';

    if (currentPassword.isEmpty ||
        newPassword.isEmpty ||
        confirmPassword.isEmpty) {
      return 'Please fill in all fields';
    }
    if (newPassword.length < 6) {
      return 'New password must be at least 6 characters';
    }
    if (newPassword != confirmPassword) {
      return 'New passwords do not match';
    }

    try {
      final credential = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );
      await user.reauthenticateWithCredential(credential);
      await user.updatePassword(newPassword);
      return null; // success
    } on FirebaseAuthException catch (e) {
      if (e.code == 'wrong-password' || e.code == 'invalid-credential') {
        return 'Current password is incorrect.';
      } else if (e.code == 'weak-password') {
        return 'New password is too weak. Use at least 6 characters.';
      } else if (e.code == 'requires-recent-login') {
        return 'Please log in again, then try changing your password.';
      }
      return e.message ?? 'Failed to change password.';
    } catch (e) {
      return 'Failed to change password: $e';
    }
  }

  Future<void> logout() async {
    await FirebaseAuth.instance.signOut();
  }

  ImageProvider get profileImageProvider {
    if (image != null) return FileImage(image!);
    return const AssetImage("assets/images/logo.png");
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    super.dispose();
  }
}
